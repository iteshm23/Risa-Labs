// Patient data types for Oncology Clinical Dashboard

export interface Patient {
  Patient_ID: string;
  Name: string;
  Age: number;
  Sex: string;
  Smoking_Status: string;
  Performance_Status: string;
  Last_Encounter_Date: string;
  Primary_Diagnosis: string;
  Histologic_Type: string;
  Diagnosis_Date: string;
  Initial_TNM_Stage: string;
  Current_TNM_Stage: string;
  Metastatic_Status: string;
  Metastatic_Sites: string;
  Recurrence_Status: string;
  Pathology_Diagnosis_Text: string;
  Tumor_Grade: string;
  Biopsy_Site: string;
  Biopsy_Date: string;
  Margin_Status: string;
  Histopathologic_Features: string;
  Pathology_Keywords: string;
  IHC_Markers: string;
  Num_Pathology_Reports: number;
  Ambiguous_Pathology: string;
  EGFR: string;
  ALK: string;
  ROS1: string;
  KRAS: string;
  BRAF: string;
  MET_Exon14: string;
  RET: string;
  HER2: string;
  NTRK: string;
  PDL1_Percent: number;
  TMB: number;
  MSI: string;
  ctDNA_Findings: string;
  Actionable_Mutation_Summary: string;
  Latest_CT_Chest: string;
  Latest_PET_CT: string;
  Radiology_Keywords: string;
  RECIST: string;
  Lesion_Count_Size: string;
  New_Lesions: string;
  Radiology_Trend: string;
  Latest_Brain_MRI: string;
  CEA: number;
  CA19_9: number;
  Other_Tumor_Markers: string;
  CBC: string;
  CMP: string;
  Electrolytes: string;
  Renal_Flag: string;
  Liver_Flag: string;
  Abnormal_Labs: string;
  Biomarker_Trend: string;
  Lab_Flag_Trend: string;
  Treatment_Plan_Summary: string;
  Prior_Therapies: string;
  Current_Line: number;
  Regimen: string;
  Treatment_Dates: string;
  Response: string;
  Reason_For_Change: string;
  Toxicities: string;
  Surgery: string;
  Radiation: string;
  Diabetes: string;
  Hypertension: string;
  Heart_Disease: string;
  COPD_Asthma: string;
  Other_Comorbidities: string;
  Stage_Changes: string;
  Radiology_Trends_Longitudinal: string;
  Biomarker_Trends_Longitudinal: string;
  New_Mutations: string;
  Treatment_Response_Timeline: string;
  Disease_Course_Summary: string;
  Pathology_Links: string;
  Genomic_Links: string;
  Radiology_Links: string;
  Provider_Notes: string;
}

export interface PatientVisit {
  Patient_ID: string;
  Visit_Date: string;
  Visit_Number: number;
  CEA: number;
  Hemoglobin: number;
  Performance_Status: string;
  Radiology_Trend: string;
  Treatment_Line: number;
  Response: string;
  Notes: string;
}

export interface ParsedCBC {
  hemoglobin: number;
  wbc: number;
  platelets: number;
}

export interface ParsedCMP {
  ast: number;
  alt: number;
  creatinine: number;
}

export interface RiskFlag {
  level: 'critical' | 'warning' | 'info';
  category: string;
  message: string;
  recommendation?: string;
}

export interface AIInsight {
  type: 'clinical' | 'molecular' | 'treatment' | 'risk' | 'trend';
  title: string;
  description: string;
  confidence: 'high' | 'medium' | 'low';
  evidence: string[];
  suggestedActions?: string[];
}

export interface TreatmentLine {
  line: number;
  regimen: string;
  startDate: string;
  endDate?: string;
  response: string;
  reasonForChange?: string;
  toxicities: string[];
}

export interface BiomarkerTrend {
  date: string;
  cea: number;
  ca199?: number;
  trend: 'rising' | 'falling' | 'stable';
}

export type ResponseType = 'CR' | 'PR' | 'SD' | 'PD' | 'Unknown';
export type RadiologyTrend = 'Improving' | 'Stable' | 'Worsening' | 'Resolved';
