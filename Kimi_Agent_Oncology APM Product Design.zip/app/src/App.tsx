import { useState } from 'react';
import { usePatientData } from '@/hooks/usePatientData';
import { PatientList } from '@/components/PatientList';
import { PatientOverview } from '@/components/PatientOverview';
import { AIInsightsPanel } from '@/components/AIInsightsPanel';
import { RiskFlagsPanel } from '@/components/RiskFlagsPanel';
import { TrendCharts } from '@/components/TrendCharts';
import { TreatmentTimeline } from '@/components/TreatmentTimeline';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Brain, 
  AlertTriangle, 
  TrendingUp, 
  Clock,
  User,
  Menu,
  X,
  Stethoscope
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import './App.css';

function App() {
  const { patients, loading, error, getPatientVisits, getPatientInsights, getPatientRiskFlags } = usePatientData();
  const [selectedPatientId, setSelectedPatientId] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const selectedPatient = patients.find(p => p.Patient_ID === selectedPatientId);
  const patientVisits = selectedPatientId ? getPatientVisits(selectedPatientId) : [];
  const patientInsights = selectedPatientId ? getPatientInsights(selectedPatientId) : [];
  const patientRiskFlags = selectedPatientId ? getPatientRiskFlags(selectedPatientId) : [];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4" />
          <p className="text-gray-600">Loading patient data...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="max-w-md">
          <CardContent className="p-6">
            <div className="text-center">
              <AlertTriangle className="h-12 w-12 text-red-600 mx-auto mb-4" />
              <h2 className="text-xl font-semibold text-gray-900 mb-2">Error Loading Data</h2>
              <p className="text-gray-600">{error}</p>
              <Button 
                className="mt-4" 
                onClick={() => window.location.reload()}
              >
                Retry
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden"
            >
              {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
            <div className="flex items-center gap-2">
              <div className="p-2 bg-blue-600 rounded-lg">
                <Stethoscope className="h-5 w-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">OncoInsight</h1>
                <p className="text-xs text-gray-500">AI-Assisted Clinical Dashboard</p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-2 text-sm text-gray-600">
              <span className="flex items-center gap-1">
                <User className="h-4 w-4" />
                {patients.length} Patients
              </span>
            </div>
            <Badge variant="outline" className="bg-purple-50 text-purple-700">
              <Brain className="h-3 w-3 mr-1" />
              AI-Enabled
            </Badge>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar - Patient List */}
        <aside 
          className={`${
            sidebarOpen ? 'translate-x-0' : '-translate-x-full'
          } fixed lg:static lg:translate-x-0 z-40 w-80 h-full bg-white border-r border-gray-200 transition-transform duration-200 ease-in-out`}
        >
          <div className="p-4 h-full flex flex-col">
            <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-3">
              Patient Roster
            </h2>
            <PatientList
              patients={patients}
              selectedPatientId={selectedPatientId}
              onSelectPatient={(id) => {
                setSelectedPatientId(id);
                if (window.innerWidth < 1024) {
                  setSidebarOpen(false);
                }
              }}
            />
          </div>
        </aside>

        {/* Overlay for mobile sidebar */}
        {sidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/50 z-30 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Main Panel */}
        <main className="flex-1 overflow-auto">
          {selectedPatient ? (
            <div className="p-4 lg:p-6 max-w-7xl mx-auto">
              {/* Patient Header */}
              <div className="mb-6">
                <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
                  <span>Patient Overview</span>
                  <span>/</span>
                  <span className="font-medium text-gray-900">{selectedPatient.Name}</span>
                </div>
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold text-gray-900">
                    {selectedPatient.Name}
                    <span className="text-lg font-normal text-gray-500 ml-2">
                      {selectedPatient.Patient_ID}
                    </span>
                  </h2>
                  <div className="flex items-center gap-2">
                    <Badge className={`
                      ${selectedPatient.Response === 'CR' || selectedPatient.Response === 'PR' ? 'bg-green-100 text-green-800' :
                        selectedPatient.Response === 'SD' ? 'bg-blue-100 text-blue-800' :
                        'bg-red-100 text-red-800'}
                    `}>
                      Response: {selectedPatient.Response}
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Main Tabs */}
              <Tabs defaultValue="overview" className="space-y-6">
                <TabsList className="grid w-full grid-cols-2 lg:grid-cols-5 gap-1">
                  <TabsTrigger value="overview" className="flex items-center gap-2">
                    <User className="h-4 w-4" />
                    <span className="hidden sm:inline">Overview</span>
                  </TabsTrigger>
                  <TabsTrigger value="insights" className="flex items-center gap-2">
                    <Brain className="h-4 w-4" />
                    <span className="hidden sm:inline">AI Insights</span>
                  </TabsTrigger>
                  <TabsTrigger value="alerts" className="flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    <span className="hidden sm:inline">Alerts</span>
                  </TabsTrigger>
                  <TabsTrigger value="trends" className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4" />
                    <span className="hidden sm:inline">Trends</span>
                  </TabsTrigger>
                  <TabsTrigger value="timeline" className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    <span className="hidden sm:inline">Timeline</span>
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="space-y-4">
                  <PatientOverview patient={selectedPatient} />
                </TabsContent>

                <TabsContent value="insights" className="space-y-4">
                  <AIInsightsPanel insights={patientInsights} />
                </TabsContent>

                <TabsContent value="alerts" className="space-y-4">
                  <RiskFlagsPanel flags={patientRiskFlags} />
                </TabsContent>

                <TabsContent value="trends" className="space-y-4">
                  <TrendCharts visits={patientVisits} />
                </TabsContent>

                <TabsContent value="timeline" className="space-y-4">
                  <TreatmentTimeline patient={selectedPatient} />
                </TabsContent>
              </Tabs>
            </div>
          ) : (
            <div className="h-full flex items-center justify-center">
              <Card className="max-w-md mx-4">
                <CardContent className="p-8 text-center">
                  <div className="p-4 bg-blue-100 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                    <User className="h-8 w-8 text-blue-600" />
                  </div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-2">
                    Select a Patient
                  </h2>
                  <p className="text-gray-600 mb-4">
                    Choose a patient from the sidebar to view their clinical dashboard, 
                    AI-generated insights, and longitudinal data.
                  </p>
                  <Button 
                    className="lg:hidden"
                    onClick={() => setSidebarOpen(true)}
                  >
                    <Menu className="h-4 w-4 mr-2" />
                    Open Patient List
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}
        </main>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-3 px-4">
        <div className="flex items-center justify-between text-xs text-gray-500">
          <div className="flex items-center gap-4">
            <span>OncoInsight Clinical Dashboard</span>
            <span>•</span>
            <span>v1.0</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <Brain className="h-3 w-3" />
              AI insights are for decision support only
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
