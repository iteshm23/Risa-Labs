import { useState, useEffect, useCallback } from 'react';
import type { Patient, PatientVisit, AIInsight, RiskFlag, ParsedCBC, ParsedCMP } from '@/types/patient';

// Parse CBC string (e.g., "Hb10.8 WBC3.4 Plt165")
export const parseCBC = (cbc: string): ParsedCBC | null => {
  if (!cbc) return null;
  const hbMatch = cbc.match(/Hb([\d.]+)/);
  const wbcMatch = cbc.match(/WBC([\d.]+)/);
  const pltMatch = cbc.match(/Plt(\d+)/);
  
  if (hbMatch && wbcMatch && pltMatch) {
    return {
      hemoglobin: parseFloat(hbMatch[1]),
      wbc: parseFloat(wbcMatch[1]),
      platelets: parseInt(pltMatch[1]),
    };
  }
  return null;
};

// Parse CMP string (e.g., "AST58 ALT72 Cr1.0")
export const parseCMP = (cmp: string): ParsedCMP | null => {
  if (!cmp) return null;
  const astMatch = cmp.match(/AST(\d+)/);
  const altMatch = cmp.match(/ALT(\d+)/);
  const crMatch = cmp.match(/Cr([\d.]+)/);
  
  if (astMatch && altMatch && crMatch) {
    return {
      ast: parseInt(astMatch[1]),
      alt: parseInt(altMatch[1]),
      creatinine: parseFloat(crMatch[1]),
    };
  }
  return null;
};

// Generate AI insights based on patient data
export const generateAIInsights = (patient: Patient): AIInsight[] => {
  const insights: AIInsight[] = [];
  
  // Parse lab values
  const cbc = parseCBC(patient.CBC);
  const cmp = parseCMP(patient.CMP);
  
  // 1. Clinical Status Insight
  const ecogMap: Record<string, number> = { 'ECOG 0': 0, 'ECOG 1': 1, 'ECOG 2': 2, 'ECOG 3': 3, 'ECOG 4': 4 };
  const ecogScore = ecogMap[patient.Performance_Status] || 0;
  
  if (ecogScore >= 2) {
    insights.push({
      type: 'clinical',
      title: 'Performance Status Decline',
      description: `Patient has ${patient.Performance_Status}, indicating reduced functional capacity. This may impact treatment tolerance and options.`,
      confidence: 'high',
      evidence: [`Current PS: ${patient.Performance_Status}`, `Baseline activity level reduced`],
      suggestedActions: ['Consider dose modifications', 'Evaluate supportive care needs', 'Assess goals of care']
    });
  }
  
  // 2. Molecular/Treatment Matching
  const actionableMutations = [];
  if (patient.EGFR !== 'Negative') actionableMutations.push(`EGFR ${patient.EGFR}`);
  if (patient.ALK === 'Positive') actionableMutations.push('ALK rearrangement');
  if (patient.KRAS !== 'Negative') actionableMutations.push(`KRAS ${patient.KRAS}`);
  if (patient.BRAF !== 'Negative') actionableMutations.push(`BRAF ${patient.BRAF}`);
  
  if (actionableMutations.length > 0) {
    insights.push({
      type: 'molecular',
      title: 'Actionable Molecular Alterations',
      description: `Patient has ${actionableMutations.join(', ')}, which may guide targeted therapy selection.`,
      confidence: 'high',
      evidence: actionableMutations,
      suggestedActions: ['Review molecular report', 'Consider targeted therapy', 'Check clinical trial eligibility']
    });
  }
  
  // 3. Immunotherapy Biomarkers
  if (patient.PDL1_Percent >= 50) {
    insights.push({
      type: 'molecular',
      title: 'High PD-L1 Expression',
      description: `PD-L1 expression is ${patient.PDL1_Percent}%, indicating potential benefit from immunotherapy.`,
      confidence: 'high',
      evidence: [`PD-L1: ${patient.PDL1_Percent}% (≥50% is high)`],
      suggestedActions: ['Consider pembrolizumab monotherapy', 'Evaluate for combination approaches']
    });
  }
  
  // 4. Treatment Response Analysis
  if (patient.Response === 'PD') {
    insights.push({
      type: 'treatment',
      title: 'Progressive Disease Detected',
      description: 'Patient shows progressive disease on current therapy. Consider treatment modification.',
      confidence: 'high',
      evidence: [`Response: ${patient.Response}`, `Radiology trend: ${patient.Radiology_Trend}`, `New lesions: ${patient.New_Lesions}`],
      suggestedActions: ['Switch to next line therapy', 'Re-biopsy for molecular testing', 'Consider clinical trial enrollment']
    });
  } else if (patient.Response === 'PR') {
    insights.push({
      type: 'treatment',
      title: 'Partial Response to Therapy',
      description: 'Patient is responding to current treatment. Continue monitoring.',
      confidence: 'high',
      evidence: [`Response: ${patient.Response}`, `RECIST: ${patient.RECIST}`],
      suggestedActions: ['Continue current therapy', 'Monitor for toxicities', 'Plan next assessment']
    });
  }
  
  // 5. Lab Abnormalities
  const labConcerns: string[] = [];
  if (cbc && cbc.hemoglobin < 10) labConcerns.push(`Anemia (Hb ${cbc.hemoglobin})`);
  if (cbc && cbc.platelets < 100) labConcerns.push(`Thrombocytopenia (Plt ${cbc.platelets})`);
  if (cmp && cmp.creatinine > 1.5) labConcerns.push(`Renal dysfunction (Cr ${cmp.creatinine})`);
  if (cmp && (cmp.ast > 50 || cmp.alt > 55)) labConcerns.push(`Elevated LFTs (AST ${cmp.ast}, ALT ${cmp.alt})`);
  
  if (labConcerns.length > 0) {
    insights.push({
      type: 'risk',
      title: 'Laboratory Abnormalities',
      description: `Multiple lab abnormalities detected: ${labConcerns.join(', ')}.`,
      confidence: 'high',
      evidence: labConcerns,
      suggestedActions: ['Review medication dosing', 'Consider supportive care', 'Monitor closely']
    });
  }
  
  // 6. CNS Disease Risk
  if (patient.Metastatic_Status === 'Yes' && patient.Latest_Brain_MRI.includes('New')) {
    insights.push({
      type: 'risk',
      title: 'CNS Progression',
      description: 'New brain metastasis detected. Requires urgent intervention.',
      confidence: 'high',
      evidence: [patient.Latest_Brain_MRI],
      suggestedActions: ['Consider radiation therapy', 'Evaluate for CNS-penetrant agents', 'Neurology consult']
    });
  }
  
  // 7. Biomarker Trend Analysis
  if (patient.Biomarker_Trend.includes('rising')) {
    insights.push({
      type: 'trend',
      title: 'Rising Tumor Marker',
      description: `${patient.Biomarker_Trend}. This may indicate early progression before radiographic changes.`,
      confidence: 'medium',
      evidence: [patient.Biomarker_Trend, `Current CEA: ${patient.CEA}`],
      suggestedActions: ['Shorten follow-up interval', 'Consider early imaging', 'Monitor symptoms']
    });
  }
  
  // 8. Comorbidity Interactions
  const comorbidities: string[] = [];
  if (patient.Diabetes !== 'None') comorbidities.push(patient.Diabetes);
  if (patient.Heart_Disease === 'Yes') comorbidities.push('Heart disease');
  if (patient.COPD_Asthma !== 'None') comorbidities.push(patient.COPD_Asthma);
  
  if (comorbidities.length > 0) {
    insights.push({
      type: 'clinical',
      title: 'Comorbidity Considerations',
      description: `Patient has ${comorbidities.join(', ')}, which may affect treatment selection and tolerance.`,
      confidence: 'medium',
      evidence: comorbidities,
      suggestedActions: ['Coordinate with specialists', 'Adjust dosing if needed', 'Monitor for drug interactions']
    });
  }
  
  return insights;
};

// Generate risk flags for patient
export const generateRiskFlags = (patient: Patient): RiskFlag[] => {
  const flags: RiskFlag[] = [];
  const cbc = parseCBC(patient.CBC);
  const cmp = parseCMP(patient.CMP);
  
  // Critical flags
  if (cbc && cbc.hemoglobin < 8) {
    flags.push({
      level: 'critical',
      category: 'Hematology',
      message: `Severe anemia (Hb ${cbc.hemoglobin})`,
      recommendation: 'Consider transfusion, evaluate for bleeding'
    });
  }
  
  if (cbc && cbc.platelets < 50) {
    flags.push({
      level: 'critical',
      category: 'Hematology',
      message: `Severe thrombocytopenia (Plt ${cbc.platelets})`,
      recommendation: 'Hold chemotherapy, consider platelet transfusion'
    });
  }
  
  if (patient.New_Lesions === 'Yes' && patient.Response === 'PD') {
    flags.push({
      level: 'critical',
      category: 'Disease Status',
      message: 'Progressive disease with new lesions',
      recommendation: 'Urgent treatment change consideration'
    });
  }
  
  // Warning flags
  if (cbc && cbc.hemoglobin >= 8 && cbc.hemoglobin < 10) {
    flags.push({
      level: 'warning',
      category: 'Hematology',
      message: `Moderate anemia (Hb ${cbc.hemoglobin})`,
      recommendation: 'Monitor, consider ESA or transfusion'
    });
  }
  
  if (cmp && cmp.creatinine > 1.5) {
    flags.push({
      level: 'warning',
      category: 'Renal',
      message: `Elevated creatinine (${cmp.creatinine})`,
      recommendation: 'Adjust renally-cleared medications'
    });
  }
  
  if (cmp && (cmp.ast > 50 || cmp.alt > 55)) {
    flags.push({
      level: 'warning',
      category: 'Hepatic',
      message: `Elevated LFTs (AST ${cmp.ast}, ALT ${cmp.alt})`,
      recommendation: 'Review hepatotoxic medications'
    });
  }
  
  const ecogMap: Record<string, number> = { 'ECOG 0': 0, 'ECOG 1': 1, 'ECOG 2': 2, 'ECOG 3': 3, 'ECOG 4': 4 };
  if ((ecogMap[patient.Performance_Status] || 0) >= 2) {
    flags.push({
      level: 'warning',
      category: 'Performance',
      message: `Reduced performance status (${patient.Performance_Status})`,
      recommendation: 'Consider dose modification, supportive care'
    });
  }
  
  // Info flags
  if (patient.Toxicities !== 'None') {
    flags.push({
      level: 'info',
      category: 'Toxicity',
      message: `Active toxicities: ${patient.Toxicities}`,
      recommendation: 'Monitor and manage symptoms'
    });
  }
  
  return flags;
};

// Custom hook for patient data
export const usePatientData = () => {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [visits, setVisits] = useState<PatientVisit[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        
        // Load patients
        const patientsResponse = await fetch('/data/oncology_patients.csv');
        if (!patientsResponse.ok) throw new Error('Failed to load patient data');
        const patientsText = await patientsResponse.text();
        
        // Parse CSV
        const parseCSV = (csvText: string): Record<string, string>[] => {
          const lines = csvText.trim().split('\n');
          const headers = lines[0].split(',').map(h => h.trim());
          return lines.slice(1).map(line => {
            const values: string[] = [];
            let inQuotes = false;
            let currentValue = '';
            
            for (let i = 0; i < line.length; i++) {
              const char = line[i];
              if (char === '"') {
                inQuotes = !inQuotes;
              } else if (char === ',' && !inQuotes) {
                values.push(currentValue.trim());
                currentValue = '';
              } else {
                currentValue += char;
              }
            }
            values.push(currentValue.trim());
            
            const record: Record<string, string> = {};
            headers.forEach((header, idx) => {
              record[header] = values[idx] || '';
            });
            return record;
          });
        };
        
        const patientsData = parseCSV(patientsText);
        
        // Convert to Patient type with proper typing
        const typedPatients: Patient[] = patientsData.map((p: Record<string, string>) => ({
          ...p,
          Age: parseInt(p.Age) || 0,
          Num_Pathology_Reports: parseInt(p.Num_Pathology_Reports) || 0,
          PDL1_Percent: parseInt(p.PDL1_Percent) || 0,
          TMB: parseInt(p.TMB) || 0,
          CEA: parseFloat(p.CEA) || 0,
          CA19_9: parseFloat(p.CA19_9) || 0,
          Current_Line: parseInt(p.Current_Line) || 0,
        } as Patient));
        
        setPatients(typedPatients);
        
        // Load visits
        const visitsResponse = await fetch('/data/patient_visits.csv');
        if (visitsResponse.ok) {
          const visitsText = await visitsResponse.text();
          const visitsData = parseCSV(visitsText);
          
          const typedVisits: PatientVisit[] = visitsData.map((v: Record<string, string>) => ({
            Patient_ID: v.Patient_ID,
            Visit_Date: v.Visit_Date,
            Visit_Number: parseInt(v.Visit_Number) || 0,
            CEA: parseFloat(v.CEA) || 0,
            Hemoglobin: parseFloat(v.Hemoglobin) || 0,
            Performance_Status: v.Performance_Status,
            Radiology_Trend: v.Radiology_Trend,
            Treatment_Line: parseInt(v.Treatment_Line) || 0,
            Response: v.Response,
            Notes: v.Notes,
          }));
          
          setVisits(typedVisits);
        }
        
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error');
      } finally {
        setLoading(false);
      }
    };
    
    loadData();
  }, []);

  const getPatientVisits = useCallback((patientId: string): PatientVisit[] => {
    return visits
      .filter(v => v.Patient_ID === patientId)
      .sort((a, b) => new Date(a.Visit_Date).getTime() - new Date(b.Visit_Date).getTime());
  }, [visits]);

  const getPatientInsights = useCallback((patientId: string): AIInsight[] => {
    const patient = patients.find(p => p.Patient_ID === patientId);
    if (!patient) return [];
    return generateAIInsights(patient);
  }, [patients]);

  const getPatientRiskFlags = useCallback((patientId: string): RiskFlag[] => {
    const patient = patients.find(p => p.Patient_ID === patientId);
    if (!patient) return [];
    return generateRiskFlags(patient);
  }, [patients]);

  return {
    patients,
    visits,
    loading,
    error,
    getPatientVisits,
    getPatientInsights,
    getPatientRiskFlags,
  };
};

export default usePatientData;
