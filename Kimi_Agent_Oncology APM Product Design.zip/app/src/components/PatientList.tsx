import { useState, useMemo } from 'react';
import type { Patient } from '@/types/patient';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Search, Filter, User, Calendar, Activity } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface PatientListProps {
  patients: Patient[];
  selectedPatientId: string | null;
  onSelectPatient: (patientId: string) => void;
}

const getResponseBadgeColor = (response: string): string => {
  switch (response) {
    case 'CR': return 'bg-green-100 text-green-800 border-green-300';
    case 'PR': return 'bg-emerald-100 text-emerald-800 border-emerald-300';
    case 'SD': return 'bg-blue-100 text-blue-800 border-blue-300';
    case 'PD': return 'bg-red-100 text-red-800 border-red-300';
    default: return 'bg-gray-100 text-gray-800 border-gray-300';
  }
};

const getRadiologyTrendColor = (trend: string): string => {
  switch (trend) {
    case 'Improving': return 'text-green-600';
    case 'Stable': return 'text-blue-600';
    case 'Worsening': return 'text-red-600';
    default: return 'text-gray-600';
  }
};

const getStageBadgeColor = (stage: string): string => {
  if (stage.includes('IV')) return 'bg-red-50 text-red-700 border-red-200';
  if (stage.includes('III')) return 'bg-orange-50 text-orange-700 border-orange-200';
  if (stage.includes('II')) return 'bg-yellow-50 text-yellow-700 border-yellow-200';
  return 'bg-green-50 text-green-700 border-green-200';
};

export function PatientList({ patients, selectedPatientId, onSelectPatient }: PatientListProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [cancerTypeFilter, setCancerTypeFilter] = useState<string>('all');
  const [stageFilter, setStageFilter] = useState<string>('all');

  const cancerTypes = useMemo(() => {
    const types = new Set(patients.map(p => p.Primary_Diagnosis));
    return Array.from(types).sort();
  }, [patients]);

  const stages = useMemo(() => {
    const stageSet = new Set(patients.map(p => p.Current_TNM_Stage));
    return Array.from(stageSet).sort();
  }, [patients]);

  const filteredPatients = useMemo(() => {
    return patients.filter(patient => {
      const matchesSearch = 
        patient.Name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        patient.Patient_ID.toLowerCase().includes(searchTerm.toLowerCase()) ||
        patient.Primary_Diagnosis.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesCancerType = cancerTypeFilter === 'all' || patient.Primary_Diagnosis === cancerTypeFilter;
      const matchesStage = stageFilter === 'all' || patient.Current_TNM_Stage === stageFilter;
      
      return matchesSearch && matchesCancerType && matchesStage;
    });
  }, [patients, searchTerm, cancerTypeFilter, stageFilter]);

  return (
    <div className="space-y-4">
      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search patients..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        
        <div className="flex gap-2">
          <Select value={cancerTypeFilter} onValueChange={setCancerTypeFilter}>
            <SelectTrigger className="flex-1">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Cancer Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              {cancerTypes.map(type => (
                <SelectItem key={type} value={type}>{type}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Select value={stageFilter} onValueChange={setStageFilter}>
            <SelectTrigger className="flex-1">
              <Activity className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Stage" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Stages</SelectItem>
              {stages.map(stage => (
                <SelectItem key={stage} value={stage}>{stage}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2 max-h-[calc(100vh-280px)] overflow-y-auto">
        {filteredPatients.map((patient) => (
          <Card
            key={patient.Patient_ID}
            className={`cursor-pointer transition-all hover:shadow-md ${
              selectedPatientId === patient.Patient_ID 
                ? 'ring-2 ring-blue-500 border-blue-500' 
                : 'border-gray-200'
            }`}
            onClick={() => onSelectPatient(patient.Patient_ID)}
          >
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-gray-500" />
                    <span className="font-semibold text-gray-900">{patient.Name}</span>
                    <span className="text-sm text-gray-500">({patient.Patient_ID})</span>
                  </div>
                  
                  <div className="flex items-center gap-2 text-sm">
                    <span className="text-gray-600">{patient.Age}y</span>
                    <span className="text-gray-400">•</span>
                    <span className="text-gray-600">{patient.Sex}</span>
                    <span className="text-gray-400">•</span>
                    <span className="text-gray-600">{patient.Primary_Diagnosis}</span>
                  </div>
                  
                  <div className="flex items-center gap-2 flex-wrap pt-1">
                    <Badge variant="outline" className={getStageBadgeColor(patient.Current_TNM_Stage)}>
                      {patient.Current_TNM_Stage}
                    </Badge>
                    <Badge variant="outline" className={getResponseBadgeColor(patient.Response)}>
                      {patient.Response}
                    </Badge>
                    {patient.Metastatic_Status === 'Yes' && (
                      <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                        Metastatic
                      </Badge>
                    )}
                  </div>
                </div>
                
                <div className="text-right space-y-1">
                  <div className="flex items-center gap-1 text-sm text-gray-500">
                    <Calendar className="h-3 w-3" />
                    <span>{patient.Last_Encounter_Date}</span>
                  </div>
                  <div className={`text-sm font-medium ${getRadiologyTrendColor(patient.Radiology_Trend)}`}>
                    {patient.Radiology_Trend}
                  </div>
                </div>
              </div>
              
              <div className="mt-3 pt-3 border-t border-gray-100">
                <div className="flex items-center justify-between text-xs text-gray-500">
                  <span>Line {patient.Current_Line}: {patient.Regimen}</span>
                  <span>PS: {patient.Performance_Status}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
        
        {filteredPatients.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            No patients match your search criteria
          </div>
        )}
      </div>
      
      <div className="text-sm text-gray-500 pt-2 border-t">
        Showing {filteredPatients.length} of {patients.length} patients
      </div>
    </div>
  );
}

export default PatientList;
