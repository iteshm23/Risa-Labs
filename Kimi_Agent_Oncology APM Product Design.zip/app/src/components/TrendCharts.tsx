import { useMemo } from 'react';
import type { PatientVisit } from '@/types/patient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  ReferenceLine
} from 'recharts';
import { TrendingUp, Activity, Droplets } from 'lucide-react';

interface TrendChartsProps {
  visits: PatientVisit[];
}

export function TrendCharts({ visits }: TrendChartsProps) {
  const chartData = useMemo(() => {
    return visits.map(visit => ({
      date: new Date(visit.Visit_Date).toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric',
        year: '2-digit'
      }),
      fullDate: visit.Visit_Date,
      CEA: visit.CEA,
      Hemoglobin: visit.Hemoglobin,
      treatmentLine: visit.Treatment_Line,
      response: visit.Response,
    }));
  }, [visits]);

  if (visits.length === 0) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-gray-500 text-center">No longitudinal data available</p>
        </CardContent>
      </Card>
    );
  }

  // Calculate trend direction
  const ceaTrend = useMemo(() => {
    if (visits.length < 2) return 'stable';
    const first = visits[0].CEA;
    const last = visits[visits.length - 1].CEA;
    const change = ((last - first) / first) * 100;
    if (change > 20) return 'rising';
    if (change < -20) return 'falling';
    return 'stable';
  }, [visits]);

  const hbTrend = useMemo(() => {
    if (visits.length < 2) return 'stable';
    const first = visits[0].Hemoglobin;
    const last = visits[visits.length - 1].Hemoglobin;
    const change = last - first;
    if (change > 0.5) return 'improving';
    if (change < -0.5) return 'declining';
    return 'stable';
  }, [visits]);

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case 'rising': return 'text-red-600';
      case 'falling': return 'text-green-600';
      case 'improving': return 'text-green-600';
      case 'declining': return 'text-red-600';
      default: return 'text-blue-600';
    }
  };

  const getTrendIcon = (trend: string) => {
    if (trend === 'rising' || trend === 'declining') {
      return <TrendingUp className="h-4 w-4 rotate-45" />;
    }
    if (trend === 'falling' || trend === 'improving') {
      return <TrendingUp className="h-4 w-4 -rotate-45" />;
    }
    return <Activity className="h-4 w-4" />;
  };

  const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: Array<{ name: string; value: number; color: string }>; label?: string }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border rounded-lg shadow-lg">
          <p className="font-medium text-gray-900">{label}</p>
          {payload.map((entry, index) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: {entry.value}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <TrendingUp className="h-5 w-5" />
          Longitudinal Trends
        </h3>
      </div>

      {/* CEA Trend Chart */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2">
              <Droplets className="h-4 w-4 text-blue-500" />
              CEA (Carcinoembryonic Antigen)
            </CardTitle>
            <div className={`flex items-center gap-1 text-sm ${getTrendColor(ceaTrend)}`}>
              {getTrendIcon(ceaTrend)}
              <span className="capitalize">{ceaTrend}</span>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis 
                  dataKey="date" 
                  tick={{ fontSize: 12 }}
                  stroke="#9ca3af"
                />
                <YAxis 
                  tick={{ fontSize: 12 }}
                  stroke="#9ca3af"
                />
                <Tooltip content={<CustomTooltip />} />
                <ReferenceLine y={5} stroke="#22c55e" strokeDasharray="3 3" label="Normal" />
                <Line 
                  type="monotone" 
                  dataKey="CEA" 
                  stroke="#3b82f6" 
                  strokeWidth={2}
                  dot={{ fill: '#3b82f6', strokeWidth: 2 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Hemoglobin Trend Chart */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2">
              <Droplets className="h-4 w-4 text-red-500" />
              Hemoglobin (g/dL)
            </CardTitle>
            <div className={`flex items-center gap-1 text-sm ${getTrendColor(hbTrend)}`}>
              {getTrendIcon(hbTrend)}
              <span className="capitalize">{hbTrend}</span>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis 
                  dataKey="date" 
                  tick={{ fontSize: 12 }}
                  stroke="#9ca3af"
                />
                <YAxis 
                  tick={{ fontSize: 12 }}
                  stroke="#9ca3af"
                  domain={[8, 14]}
                />
                <Tooltip content={<CustomTooltip />} />
                <ReferenceLine y={12} stroke="#22c55e" strokeDasharray="3 3" label="Normal (F)" />
                <ReferenceLine y={13.5} stroke="#16a34a" strokeDasharray="3 3" label="Normal (M)" />
                <ReferenceLine y={10} stroke="#ef4444" strokeDasharray="3 3" label="Anemia" />
                <Line 
                  type="monotone" 
                  dataKey="Hemoglobin" 
                  stroke="#ef4444" 
                  strokeWidth={2}
                  dot={{ fill: '#ef4444', strokeWidth: 2 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Treatment Response Timeline */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Activity className="h-4 w-4 text-purple-500" />
            Treatment Response by Visit
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {visits.map((visit, index) => (
              <div 
                key={index} 
                className="flex items-center justify-between p-2 rounded-lg bg-gray-50"
              >
                <div className="flex items-center gap-3">
                  <span className="text-sm text-gray-500">
                    {new Date(visit.Visit_Date).toLocaleDateString()}
                  </span>
                  <span className="text-sm font-medium">
                    Line {visit.Treatment_Line}
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    visit.Response === 'CR' ? 'bg-green-100 text-green-800' :
                    visit.Response === 'PR' ? 'bg-emerald-100 text-emerald-800' :
                    visit.Response === 'SD' ? 'bg-blue-100 text-blue-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {visit.Response}
                  </span>
                  <span className={`text-xs ${
                    visit.Radiology_Trend === 'Improving' ? 'text-green-600' :
                    visit.Radiology_Trend === 'Stable' ? 'text-blue-600' :
                    'text-red-600'
                  }`}>
                    {visit.Radiology_Trend}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default TrendCharts;
