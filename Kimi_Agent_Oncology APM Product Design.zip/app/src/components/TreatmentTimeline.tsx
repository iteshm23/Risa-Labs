import type { Patient } from '@/types/patient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Scissors, 
  Radiation, 
  Pill, 
  CheckCircle, 
  XCircle, 
  MinusCircle,
  AlertCircle,
  Clock
} from 'lucide-react';

interface TreatmentTimelineProps {
  patient: Patient;
}

const getResponseBadge = (response: string) => {
  switch (response) {
    case 'CR':
      return <Badge className="bg-green-100 text-green-800">Complete Response</Badge>;
    case 'PR':
      return <Badge className="bg-emerald-100 text-emerald-800">Partial Response</Badge>;
    case 'SD':
      return <Badge className="bg-blue-100 text-blue-800">Stable Disease</Badge>;
    case 'PD':
      return <Badge className="bg-red-100 text-red-800">Progressive Disease</Badge>;
    default:
      return <Badge className="bg-gray-100 text-gray-800">Unknown</Badge>;
  }
};

const getResponseIcon = (response: string) => {
  switch (response) {
    case 'CR':
    case 'PR':
      return <CheckCircle className="h-5 w-5 text-green-600" />;
    case 'SD':
      return <MinusCircle className="h-5 w-5 text-blue-600" />;
    case 'PD':
      return <XCircle className="h-5 w-5 text-red-600" />;
    default:
      return <AlertCircle className="h-5 w-5 text-gray-600" />;
  }
};

export function TreatmentTimeline({ patient }: TreatmentTimelineProps) {
  // Build timeline events
  const events: Array<{
    date: string;
    type: 'diagnosis' | 'surgery' | 'radiation' | 'treatment' | 'response';
    title: string;
    description: string;
    details?: string;
    icon: React.ReactNode;
  }> = [];

  // Add diagnosis
  events.push({
    date: patient.Diagnosis_Date,
    type: 'diagnosis',
    title: 'Diagnosis',
    description: `${patient.Primary_Diagnosis} - ${patient.Histologic_Type}`,
    details: `Stage: ${patient.Initial_TNM_Stage}`,
    icon: <AlertCircle className="h-5 w-5 text-blue-600" />
  });

  // Add surgery if present
  if (patient.Surgery && patient.Surgery !== 'None') {
    const surgeryMatch = patient.Surgery.match(/(.+?)\s+(\d{4})/);
    if (surgeryMatch) {
      events.push({
        date: `${surgeryMatch[2]}-01-01`, // Approximate date
        type: 'surgery',
        title: 'Surgery',
        description: surgeryMatch[1],
        icon: <Scissors className="h-5 w-5 text-purple-600" />
      });
    }
  }

  // Add radiation if present
  if (patient.Radiation && patient.Radiation !== 'None') {
    const radMatch = patient.Radiation.match(/(.+?)\s+(\d{4}-\d{2}-\d{2})/);
    if (radMatch) {
      events.push({
        date: radMatch[2],
        type: 'radiation',
        title: 'Radiation Therapy',
        description: radMatch[1],
        icon: <Radiation className="h-5 w-5 text-orange-600" />
      });
    }
  }

  // Add prior therapies
  if (patient.Prior_Therapies && patient.Prior_Therapies !== 'None') {
    events.push({
      date: patient.Diagnosis_Date, // Approximate
      type: 'treatment',
      title: 'Prior Therapy',
      description: patient.Prior_Therapies,
      details: 'Line 1',
      icon: <Pill className="h-5 w-5 text-teal-600" />
    });
  }

  // Add current treatment
  const treatmentStartMatch = patient.Treatment_Dates.match(/(\d{4}-\d{2}-\d{2})/);
  if (treatmentStartMatch) {
    events.push({
      date: treatmentStartMatch[1],
      type: 'treatment',
      title: `Line ${patient.Current_Line} Therapy`,
      description: patient.Regimen,
      details: 'Ongoing',
      icon: <Pill className="h-5 w-5 text-green-600" />
    });
  }

  // Sort events by date
  events.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <Clock className="h-5 w-5" />
          Treatment Timeline
        </h3>
        <div className="flex items-center gap-2">
          {getResponseBadge(patient.Response)}
        </div>
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gray-200" />
            
            <div className="space-y-6">
              {events.map((event, index) => (
                <div key={index} className="relative flex items-start gap-4">
                  {/* Timeline dot */}
                  <div className="relative z-10 flex-shrink-0 w-12 h-12 rounded-full bg-white border-2 border-gray-200 flex items-center justify-center">
                    {event.icon}
                  </div>
                  
                  {/* Event content */}
                  <div className="flex-1 pt-2">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm text-gray-500">
                        {new Date(event.date).toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric'
                        })}
                      </span>
                      <Badge variant="outline" className="text-xs">
                        {event.type.charAt(0).toUpperCase() + event.type.slice(1)}
                      </Badge>
                    </div>
                    <h4 className="font-medium text-gray-900">{event.title}</h4>
                    <p className="text-sm text-gray-600">{event.description}</p>
                    {event.details && (
                      <p className="text-sm text-gray-500 mt-1">{event.details}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Current Status Summary */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardContent className="p-4">
          <div className="flex items-start gap-4">
            <div className="p-2 bg-white rounded-full">
              {getResponseIcon(patient.Response)}
            </div>
            <div className="flex-1">
              <h4 className="font-semibold text-gray-900">Current Status</h4>
              <p className="text-sm text-gray-700 mt-1">
                {patient.Treatment_Response_Timeline}
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                <Badge variant="outline" className="bg-white">
                  {patient.Radiology_Trend} on imaging
                </Badge>
                {patient.New_Lesions === 'Yes' && (
                  <Badge className="bg-red-100 text-red-800">
                    New lesions detected
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Toxicities */}
      {patient.Toxicities && patient.Toxicities !== 'None' && (
        <Card className="border-amber-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <AlertCircle className="h-4 w-4 text-amber-600" />
              Current Toxicities
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {patient.Toxicities.split('|').map((toxicity, i) => (
                <Badge key={i} className="bg-amber-100 text-amber-800">
                  {toxicity.trim()}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Reason for Change */}
      {patient.Reason_For_Change && patient.Reason_For_Change !== 'N/A' && (
        <Card className="border-gray-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Reason for Treatment Change</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-700">{patient.Reason_For_Change}</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export default TreatmentTimeline;
