import type { RiskFlag } from '@/types/patient';
import { AlertTriangle, AlertCircle, Info, Shield } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface RiskFlagsPanelProps {
  flags: RiskFlag[];
}

const getFlagIcon = (level: string) => {
  switch (level) {
    case 'critical':
      return <AlertTriangle className="h-5 w-5 text-red-600" />;
    case 'warning':
      return <AlertCircle className="h-5 w-5 text-amber-600" />;
    case 'info':
      return <Info className="h-5 w-5 text-blue-600" />;
    default:
      return <Info className="h-5 w-5 text-gray-600" />;
  }
};

const getFlagStyles = (level: string) => {
  switch (level) {
    case 'critical':
      return 'bg-red-50 border-red-200 text-red-900';
    case 'warning':
      return 'bg-amber-50 border-amber-200 text-amber-900';
    case 'info':
      return 'bg-blue-50 border-blue-200 text-blue-900';
    default:
      return 'bg-gray-50 border-gray-200 text-gray-900';
  }
};

const getBadgeStyles = (level: string) => {
  switch (level) {
    case 'critical':
      return 'bg-red-100 text-red-800 border-red-300';
    case 'warning':
      return 'bg-amber-100 text-amber-800 border-amber-300';
    case 'info':
      return 'bg-blue-100 text-blue-800 border-blue-300';
    default:
      return 'bg-gray-100 text-gray-800 border-gray-300';
  }
};

export function RiskFlagsPanel({ flags }: RiskFlagsPanelProps) {
  if (flags.length === 0) {
    return (
      <Card className="border-green-200">
        <CardContent className="p-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-green-100 rounded-full">
              <Shield className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <h3 className="font-semibold text-green-900">No Active Alerts</h3>
              <p className="text-sm text-green-700">No critical issues identified for this patient</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const criticalFlags = flags.filter(f => f.level === 'critical');
  const warningFlags = flags.filter(f => f.level === 'warning');

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <Shield className="h-5 w-5" />
          Clinical Alerts
        </h3>
        <div className="flex gap-2">
          {criticalFlags.length > 0 && (
            <Badge className="bg-red-100 text-red-800">
              {criticalFlags.length} Critical
            </Badge>
          )}
          {warningFlags.length > 0 && (
            <Badge className="bg-amber-100 text-amber-800">
              {warningFlags.length} Warning
            </Badge>
          )}
        </div>
      </div>

      {flags.map((flag, index) => (
        <Card 
          key={index} 
          className={`border ${getFlagStyles(flag.level)}`}
        >
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="mt-0.5">
                {getFlagIcon(flag.level)}
              </div>
              <div className="flex-1 space-y-1">
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className={getBadgeStyles(flag.level)}>
                    {flag.category}
                  </Badge>
                  <span className={`text-xs font-medium uppercase ${
                    flag.level === 'critical' ? 'text-red-700' : 
                    flag.level === 'warning' ? 'text-amber-700' : 'text-blue-700'
                  }`}>
                    {flag.level}
                  </span>
                </div>
                <p className="font-medium">{flag.message}</p>
                {flag.recommendation && (
                  <p className="text-sm opacity-80">
                    <span className="font-medium">Recommendation:</span> {flag.recommendation}
                  </p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

export default RiskFlagsPanel;
