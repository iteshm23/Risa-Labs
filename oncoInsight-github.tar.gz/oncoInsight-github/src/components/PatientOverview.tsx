import type { Patient } from '@/types/patient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  User, 
  Calendar, 
  Activity, 
  Microscope, 
  Pill, 
  AlertTriangle,
  CheckCircle,
  XCircle,
  MinusCircle,
  FileText
} from 'lucide-react';

interface PatientOverviewProps {
  patient: Patient;
}

const getResponseIcon = (response: string) => {
  switch (response) {
    case 'CR':
      return <CheckCircle className="h-5 w-5 text-green-600" />;
    case 'PR':
      return <CheckCircle className="h-5 w-5 text-emerald-600" />;
    case 'SD':
      return <MinusCircle className="h-5 w-5 text-blue-600" />;
    case 'PD':
      return <XCircle className="h-5 w-5 text-red-600" />;
    default:
      return <Activity className="h-5 w-5 text-gray-600" />;
  }
};

const getResponseLabel = (response: string): string => {
  switch (response) {
    case 'CR': return 'Complete Response';
    case 'PR': return 'Partial Response';
    case 'SD': return 'Stable Disease';
    case 'PD': return 'Progressive Disease';
    default: return 'Unknown';
  }
};

const getStageBadgeColor = (stage: string): string => {
  if (stage.includes('IV')) return 'bg-red-100 text-red-800 border-red-300';
  if (stage.includes('III')) return 'bg-orange-100 text-orange-800 border-orange-300';
  if (stage.includes('II')) return 'bg-yellow-100 text-yellow-800 border-yellow-300';
  return 'bg-green-100 text-green-800 border-green-300';
};

export function PatientOverview({ patient }: PatientOverviewProps) {
  const parseCBC = (cbc: string) => {
    const hbMatch = cbc.match(/Hb([\d.]+)/);
    const wbcMatch = cbc.match(/WBC([\d.]+)/);
    const pltMatch = cbc.match(/Plt(\d+)/);
    return {
      hb: hbMatch ? parseFloat(hbMatch[1]) : null,
      wbc: wbcMatch ? parseFloat(wbcMatch[1]) : null,
      plt: pltMatch ? parseInt(pltMatch[1]) : null,
    };
  };

  const parseCMP = (cmp: string) => {
    const astMatch = cmp.match(/AST(\d+)/);
    const altMatch = cmp.match(/ALT(\d+)/);
    const crMatch = cmp.match(/Cr([\d.]+)/);
    return {
      ast: astMatch ? parseInt(astMatch[1]) : null,
      alt: altMatch ? parseInt(altMatch[1]) : null,
      cr: crMatch ? parseFloat(crMatch[1]) : null,
    };
  };

  const cbc = parseCBC(patient.CBC);
  const cmp = parseCMP(patient.CMP);

  // Get actionable mutations
  const actionableMuts = [];
  if (patient.EGFR !== 'Negative') actionableMuts.push(`EGFR ${patient.EGFR}`);
  if (patient.ALK === 'Positive') actionableMuts.push('ALK+');
  if (patient.KRAS !== 'Negative') actionableMuts.push(`KRAS ${patient.KRAS}`);
  if (patient.BRAF !== 'Negative') actionableMuts.push(`BRAF ${patient.BRAF}`);

  return (
    <div className="space-y-4">
      {/* Patient Header */}
      <Card className="border-blue-200 bg-gradient-to-r from-blue-50 to-white">
        <CardContent className="p-4">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <User className="h-5 w-5 text-blue-600" />
                <h2 className="text-xl font-bold text-gray-900">{patient.Name}</h2>
                <span className="text-sm text-gray-500">{patient.Patient_ID}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <span>{patient.Age} years</span>
                <span>•</span>
                <span>{patient.Sex}</span>
                <span>•</span>
                <span>{patient.Smoking_Status} smoker</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Calendar className="h-4 w-4 text-gray-400" />
                <span className="text-gray-600">Diagnosed: {patient.Diagnosis_Date}</span>
                <span className="text-gray-400">|</span>
                <span className="text-gray-600">Last visit: {patient.Last_Encounter_Date}</span>
              </div>
            </div>
            <div className="text-right space-y-2">
              <Badge className={getStageBadgeColor(patient.Current_TNM_Stage)}>
                {patient.Current_TNM_Stage}
              </Badge>
              {patient.Metastatic_Status === 'Yes' && (
                <Badge className="bg-purple-100 text-purple-800 block mt-1">
                  Metastatic
                </Badge>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Disease Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Microscope className="h-4 w-4 text-purple-600" />
              Diagnosis & Pathology
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Primary Diagnosis</span>
              <span className="text-sm font-medium">{patient.Primary_Diagnosis}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Histology</span>
              <span className="text-sm font-medium">{patient.Histologic_Type}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Grade</span>
              <span className="text-sm font-medium">{patient.Tumor_Grade}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Stage Progression</span>
              <span className="text-sm font-medium">{patient.Stage_Changes}</span>
            </div>
            {patient.Metastatic_Sites && (
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Metastatic Sites</span>
                <span className="text-sm font-medium text-right">{patient.Metastatic_Sites.replace(/\|/g, ', ')}</span>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Pill className="h-4 w-4 text-green-600" />
              Current Treatment
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Line of Therapy</span>
              <span className="text-sm font-medium">Line {patient.Current_Line}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Regimen</span>
              <span className="text-sm font-medium text-right">{patient.Regimen}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Treatment Dates</span>
              <span className="text-sm font-medium">{patient.Treatment_Dates}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Response</span>
              <div className="flex items-center gap-2">
                {getResponseIcon(patient.Response)}
                <span className="text-sm font-medium">{getResponseLabel(patient.Response)}</span>
              </div>
            </div>
            {patient.Prior_Therapies && patient.Prior_Therapies !== 'None' && (
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Prior Therapies</span>
                <span className="text-sm font-medium">{patient.Prior_Therapies}</span>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Molecular Profile */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Activity className="h-4 w-4 text-indigo-600" />
            Molecular Profile
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="p-2 bg-gray-50 rounded">
              <span className="text-xs text-gray-500 block">EGFR</span>
              <span className={`text-sm font-medium ${patient.EGFR !== 'Negative' ? 'text-green-700' : 'text-gray-700'}`}>
                {patient.EGFR}
              </span>
            </div>
            <div className="p-2 bg-gray-50 rounded">
              <span className="text-xs text-gray-500 block">ALK</span>
              <span className={`text-sm font-medium ${patient.ALK === 'Positive' ? 'text-green-700' : 'text-gray-700'}`}>
                {patient.ALK}
              </span>
            </div>
            <div className="p-2 bg-gray-50 rounded">
              <span className="text-xs text-gray-500 block">KRAS</span>
              <span className={`text-sm font-medium ${patient.KRAS !== 'Negative' ? 'text-green-700' : 'text-gray-700'}`}>
                {patient.KRAS}
              </span>
            </div>
            <div className="p-2 bg-gray-50 rounded">
              <span className="text-xs text-gray-500 block">BRAF</span>
              <span className={`text-sm font-medium ${patient.BRAF !== 'Negative' ? 'text-green-700' : 'text-gray-700'}`}>
                {patient.BRAF}
              </span>
            </div>
            <div className="p-2 bg-gray-50 rounded">
              <span className="text-xs text-gray-500 block">PD-L1</span>
              <span className={`text-sm font-medium ${patient.PDL1_Percent >= 50 ? 'text-green-700' : 'text-gray-700'}`}>
                {patient.PDL1_Percent}%
              </span>
            </div>
            <div className="p-2 bg-gray-50 rounded">
              <span className="text-xs text-gray-500 block">TMB</span>
              <span className="text-sm font-medium">{patient.TMB} mut/Mb</span>
            </div>
            <div className="p-2 bg-gray-50 rounded">
              <span className="text-xs text-gray-500 block">MSI</span>
              <span className={`text-sm font-medium ${patient.MSI === 'MSI-H' ? 'text-green-700' : 'text-gray-700'}`}>
                {patient.MSI}
              </span>
            </div>
            <div className="p-2 bg-gray-50 rounded">
              <span className="text-xs text-gray-500 block">HER2</span>
              <span className={`text-sm font-medium ${patient.HER2 === 'Positive' ? 'text-green-700' : 'text-gray-700'}`}>
                {patient.HER2}
              </span>
            </div>
          </div>
          
          {actionableMuts.length > 0 && (
            <div className="mt-3 p-2 bg-green-50 border border-green-200 rounded">
              <span className="text-xs text-green-700 font-medium block mb-1">Actionable Alterations:</span>
              <div className="flex flex-wrap gap-1">
                {actionableMuts.map((mut, i) => (
                  <Badge key={i} className="bg-green-100 text-green-800">
                    {mut}
                  </Badge>
                ))}
              </div>
            </div>
          )}
          
          {patient.ctDNA_Findings && patient.ctDNA_Findings !== 'None detected' && (
            <div className="mt-2 text-sm">
              <span className="text-gray-600">ctDNA: </span>
              <span className="font-medium">{patient.ctDNA_Findings}</span>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Labs */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <FileText className="h-4 w-4 text-orange-600" />
            Recent Laboratory Values
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {/* CBC */}
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-gray-700">CBC</h4>
              {cbc.hb !== null && (
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Hemoglobin</span>
                  <span className={`font-medium ${cbc.hb < 10 ? 'text-red-600' : ''}`}>
                    {cbc.hb} g/dL
                  </span>
                </div>
              )}
              {cbc.wbc !== null && (
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">WBC</span>
                  <span className={`font-medium ${cbc.wbc < 4 || cbc.wbc > 11 ? 'text-amber-600' : ''}`}>
                    {cbc.wbc} K/μL
                  </span>
                </div>
              )}
              {cbc.plt !== null && (
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Platelets</span>
                  <span className={`font-medium ${cbc.plt < 150 ? 'text-amber-600' : ''}`}>
                    {cbc.plt} K/μL
                  </span>
                </div>
              )}
            </div>

            {/* CMP */}
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-gray-700">CMP</h4>
              {cmp.ast !== null && (
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">AST</span>
                  <span className={`font-medium ${cmp.ast > 40 ? 'text-amber-600' : ''}`}>
                    {cmp.ast} U/L
                  </span>
                </div>
              )}
              {cmp.alt !== null && (
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">ALT</span>
                  <span className={`font-medium ${cmp.alt > 40 ? 'text-amber-600' : ''}`}>
                    {cmp.alt} U/L
                  </span>
                </div>
              )}
              {cmp.cr !== null && (
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Creatinine</span>
                  <span className={`font-medium ${cmp.cr > 1.5 ? 'text-red-600' : ''}`}>
                    {cmp.cr} mg/dL
                  </span>
                </div>
              )}
            </div>

            {/* Tumor Markers */}
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-gray-700">Tumor Markers</h4>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">CEA</span>
                <span className={`font-medium ${patient.CEA > 5 ? 'text-amber-600' : 'text-green-600'}`}>
                  {patient.CEA} ng/mL
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">CA 19-9</span>
                <span className={`font-medium ${patient.CA19_9 > 37 ? 'text-amber-600' : ''}`}>
                  {patient.CA19_9} U/mL
                </span>
              </div>
            </div>
          </div>

          {/* Abnormal Labs Summary */}
          {patient.Abnormal_Labs && patient.Abnormal_Labs !== 'None' && (
            <div className="mt-3 p-2 bg-amber-50 border border-amber-200 rounded flex items-start gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-600 mt-0.5" />
              <div>
                <span className="text-xs text-amber-700 font-medium block">Abnormal Findings:</span>
                <span className="text-sm text-amber-800">{patient.Abnormal_Labs.replace(/\|/g, ', ')}</span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Comorbidities */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Activity className="h-4 w-4 text-teal-600" />
            Comorbidities
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {patient.Diabetes !== 'None' && (
              <Badge variant="outline" className="bg-orange-50 text-orange-700">
                {patient.Diabetes}
              </Badge>
            )}
            {patient.Hypertension === 'Yes' && (
              <Badge variant="outline" className="bg-red-50 text-red-700">
                Hypertension
              </Badge>
            )}
            {patient.Heart_Disease === 'Yes' && (
              <Badge variant="outline" className="bg-red-50 text-red-700">
                Heart Disease
              </Badge>
            )}
            {patient.COPD_Asthma !== 'None' && (
              <Badge variant="outline" className="bg-blue-50 text-blue-700">
                {patient.COPD_Asthma}
              </Badge>
            )}
            {patient.Other_Comorbidities && patient.Other_Comorbidities !== 'None' && (
              <Badge variant="outline" className="bg-gray-50 text-gray-700">
                {patient.Other_Comorbidities}
              </Badge>
            )}
            {patient.Diabetes === 'None' && patient.Hypertension === 'No' && 
             patient.Heart_Disease === 'No' && patient.COPD_Asthma === 'None' && (
              <span className="text-sm text-gray-500">No significant comorbidities</span>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Disease Course Summary */}
      <Card className="bg-gray-50">
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <FileText className="h-4 w-4 text-gray-600" />
            Disease Course Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-700">{patient.Disease_Course_Summary}</p>
          <div className="mt-3 grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-500 block">Radiology Trend</span>
              <span className={`font-medium ${
                patient.Radiology_Trend === 'Improving' ? 'text-green-600' :
                patient.Radiology_Trend === 'Stable' ? 'text-blue-600' :
                'text-red-600'
              }`}>
                {patient.Radiology_Trend}
              </span>
            </div>
            <div>
              <span className="text-gray-500 block">Biomarker Trend</span>
              <span className="font-medium">{patient.Biomarker_Trend}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default PatientOverview;
