import type { AIInsight } from '@/types/patient';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Brain, TrendingUp, Microscope, Pill, AlertCircle, CheckCircle, Lightbulb } from 'lucide-react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

interface AIInsightsPanelProps {
  insights: AIInsight[];
}

const getInsightIcon = (type: string) => {
  switch (type) {
    case 'clinical':
      return <CheckCircle className="h-5 w-5 text-blue-600" />;
    case 'molecular':
      return <Microscope className="h-5 w-5 text-purple-600" />;
    case 'treatment':
      return <Pill className="h-5 w-5 text-green-600" />;
    case 'risk':
      return <AlertCircle className="h-5 w-5 text-red-600" />;
    case 'trend':
      return <TrendingUp className="h-5 w-5 text-amber-600" />;
    default:
      return <Lightbulb className="h-5 w-5 text-gray-600" />;
  }
};

const getInsightBadgeColor = (type: string) => {
  switch (type) {
    case 'clinical':
      return 'bg-blue-100 text-blue-800 border-blue-300';
    case 'molecular':
      return 'bg-purple-100 text-purple-800 border-purple-300';
    case 'treatment':
      return 'bg-green-100 text-green-800 border-green-300';
    case 'risk':
      return 'bg-red-100 text-red-800 border-red-300';
    case 'trend':
      return 'bg-amber-100 text-amber-800 border-amber-300';
    default:
      return 'bg-gray-100 text-gray-800 border-gray-300';
  }
};

const getConfidenceBadge = (confidence: string) => {
  switch (confidence) {
    case 'high':
      return <Badge className="bg-green-100 text-green-800">High Confidence</Badge>;
    case 'medium':
      return <Badge className="bg-yellow-100 text-yellow-800">Medium Confidence</Badge>;
    case 'low':
      return <Badge className="bg-gray-100 text-gray-800">Low Confidence</Badge>;
    default:
      return null;
  }
};

export function AIInsightsPanel({ insights }: AIInsightsPanelProps) {
  if (insights.length === 0) {
    return (
      <Card className="border-gray-200">
        <CardContent className="p-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gray-100 rounded-full">
              <Brain className="h-5 w-5 text-gray-600" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">No AI Insights Available</h3>
              <p className="text-sm text-gray-600">Insufficient data to generate clinical insights</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Group insights by type
  const groupedInsights = insights.reduce((acc, insight) => {
    if (!acc[insight.type]) acc[insight.type] = [];
    acc[insight.type].push(insight);
    return acc;
  }, {} as Record<string, AIInsight[]>);

  const typeOrder = ['risk', 'treatment', 'molecular', 'clinical', 'trend'];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <Brain className="h-5 w-5 text-purple-600" />
          AI-Generated Insights
          <span className="text-xs font-normal text-gray-500 ml-2">
            (Decision Support Only)
          </span>
        </h3>
        <Badge variant="outline" className="bg-purple-50 text-purple-700">
          {insights.length} Insights
        </Badge>
      </div>

      <Accordion type="multiple" defaultValue={['risk-0']} className="space-y-2">
        {typeOrder.map((type) => {
          const typeInsights = groupedInsights[type];
          if (!typeInsights || typeInsights.length === 0) return null;

          return typeInsights.map((insight, index) => (
            <AccordionItem 
              key={`${type}-${index}`} 
              value={`${type}-${index}`}
              className="border rounded-lg overflow-hidden"
            >
              <AccordionTrigger className="px-4 py-3 hover:no-underline hover:bg-gray-50">
                <div className="flex items-center gap-3 text-left">
                  {getInsightIcon(insight.type)}
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="outline" className={getInsightBadgeColor(insight.type)}>
                        {insight.type.charAt(0).toUpperCase() + insight.type.slice(1)}
                      </Badge>
                      {getConfidenceBadge(insight.confidence)}
                    </div>
                    <span className="font-medium text-gray-900">{insight.title}</span>
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="px-4 pb-4">
                <div className="pl-8 space-y-3">
                  <p className="text-gray-700">{insight.description}</p>
                  
                  {insight.evidence && insight.evidence.length > 0 && (
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-gray-600">Evidence:</p>
                      <ul className="text-sm text-gray-600 space-y-1">
                        {insight.evidence.map((ev, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <span className="text-gray-400">•</span>
                            {ev}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  {insight.suggestedActions && insight.suggestedActions.length > 0 && (
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-gray-600">Suggested Considerations:</p>
                      <ul className="text-sm text-gray-600 space-y-1">
                        {insight.suggestedActions.map((action, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <span className="text-blue-500">→</span>
                            {action}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  <div className="pt-2 border-t">
                    <p className="text-xs text-gray-500 italic">
                      This insight is generated by AI for decision support only. 
                      Clinical judgment should always prevail.
                    </p>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          ));
        })}
      </Accordion>
    </div>
  );
}

export default AIInsightsPanel;
